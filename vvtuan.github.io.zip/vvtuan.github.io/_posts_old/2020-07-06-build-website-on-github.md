---
layout: post
title:  "Kinh nghiệm tạo website cá nhân với Jekyll"
subtitle: "Một số kinh nghiệm tôi thu được sau khi chuyển website cá nhân từ Wordpress sang Jekyll"
date:   2020-07-06
categories: [Jekyll]
tags: [Jekyll, website]
permalink: /blogging/kinh-nghiem-tao-webiste-ca-nhan-voi-jekyll/
bigimg: "/assets/img/blogging/jekyll/jekyllhomepage.png"
---

# Title
## Heading 1
### Heading 2
#### Heading 3
